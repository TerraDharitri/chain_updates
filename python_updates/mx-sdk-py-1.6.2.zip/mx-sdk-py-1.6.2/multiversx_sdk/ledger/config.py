class LedgerAppConfiguration:
    data_activated: bool
    account_index: int
    address_index: int
    version: str
