This project is deprecated, use the [available SDKs](https://docs.multiversx.com/sdk-and-tools/overview) !
