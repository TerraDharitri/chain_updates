# Examples: using wallet components

```bash
node ./index.js
```
