---
sidebar_position: 30
id: how-to-trade
sidebar_label: Trade
title: How to trade
---

<div style={{ textAlign: 'center' }}>
    <img src="/docs/how-to/trade/trade-tokens.png" alt="Trade Tokens" width="560"/>
</div>

1. Log in to xExchange
2. Select “Trade” from the top menu
3. The trade interface presents you enables you to select the original token (”Trade From”) and destination token (”Trade To”)
4. Select the two tokens
5. Enter the amount of the original token that you want to trade out of
6. The amount of the destination token will be automatically calculated based on its current price
7. Click Continue
8. You will be asked to confirm 1 transaction, as per your login method -> Confirm
9. The transaction will be sent and your new balances will be automatically updated, pending the transactions’ execution

Tip: You can change the slippage in the Settings menu.
