---
sidebar_position: 60
id: how-to-claim-rewards
sidebar_label: Claim Rewards
title: How to claim your rewards
---

<div style={{ textAlign: 'center' }}>
    <img src="/docs/how-to/claim-rewards/portfolio.png" alt="Claim Rewards" width="724" />
</div>

Users can manage all their rewards directly on the Portfolio page.
You can either claim the rewards individually, all at once, or directly reinvest them. Reinvesting is available only for Staking positions

<div style={{ textAlign: 'center' }}>
  <img src="/docs/how-to/claim-rewards/claim-rewards.png" alt="Claim Rewards" width="724" />
</div>

"Claim all” - claims all the available base, Energy and fees rewards for all the positions, at once. Once claimed, the rewards amounts will become available in your wallet, as displayed under Total balances

“Reinvest all” - reinvests all the available rewards for all Staking Positions. All the rewards are thus automatically staked into the farm.

<div style={{ textAlign: 'center' }}>
  <img src="/docs/how-to/claim-rewards/claim-reward.png" alt="Claim Reward" width="724" />
</div>

“Claim” - claim the available base and Energy rewards for that position. Rewards thus become available in your wallet balances

<div style={{ textAlign: 'center' }}>
  <img src="/docs/how-to/claim-rewards/reinvest-reward.png" alt="Reinvest Reward" width="724" />
</div>

“Reinvest” - reinvests the available rewards for that position. Rewards are thus automatically staked into the farm
