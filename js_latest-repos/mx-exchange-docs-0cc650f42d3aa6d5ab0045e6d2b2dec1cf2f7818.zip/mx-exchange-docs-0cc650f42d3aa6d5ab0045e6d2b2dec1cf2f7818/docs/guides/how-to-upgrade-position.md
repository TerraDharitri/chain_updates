---
sidebar_position: 80
id: how-to-uprade-position
sidebar_label: Upgrade Position
title: How to upgrade liquidity positions
---

1. Log in to xExchange
2. Go to the Portfolio page

<div style={{ textAlign: 'center' }}>
  <img src="/docs/how-to/upgrade-position/section.png" alt="Section" width="724" />
</div>

3. Scroll to the “Liquidity Positions” section
4. Expand the Pool to see the underlying positions
5. Open the dropdown menu for the desired position and click “Upgrade position”

<div style={{ textAlign: 'center' }}>
  <img src="/docs/how-to/upgrade-position/position.png" alt="Position" width="724" />
</div>

6. You will be redirected to the Upgrade Position page

<div style={{ textAlign: 'center' }}>
  <img src="/docs/how-to/upgrade-position/amount.png" alt="Amount" width="724" />
</div>

7. Select the position type that you want to upgrade and the amount of tokens\*
8. Click on “Upgrade”
9. You will be asked to confirm 1 transaction, as per your login method -> confirm
10. The transaction will be sent and your new balances will be automatically updated, pending the transaction's execution

:::tip
Some pools won't have a Farm or Dual Farm rewards tier
:::
