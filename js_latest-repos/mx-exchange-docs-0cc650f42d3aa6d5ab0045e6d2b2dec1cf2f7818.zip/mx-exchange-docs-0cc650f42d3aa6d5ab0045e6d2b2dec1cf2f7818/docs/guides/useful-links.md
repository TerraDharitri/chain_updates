---
sidebar_position: 130
id: useful-links
sidebar_label: 🔗 Useful Links
title: Useful Links
---

[comment]: # "mx-context-auto"

Wallets:

- [https://wallet.multiversx.com](https://wallet.multiversx.com)
- [https://xportal.com](https://xportal.com)
- [MultiversX DeFi Wallet (Chrome)](https://chrome.google.com/webstore/detail/multiversx-defi-wallet/dngmlblcodfobpdpecaadgfbcggfjfnm)
- [MultiversX DeFi Wallet (Firefox)](https://addons.mozilla.org/firefox/addon/multiversx-defi-wallet/)
- [https://ledger.com](https://ledger.com)
- [https://github.com/multiversx/mx-exchange-sc](https://github.com/multiversx/mx-exchange-sc)
- [https://assets.multiversx.com](https://assets.multiversx.com)

xExchange Agora:

- [https://agora.xexchange.com](https://agora.xexchange.com)

Tutorials:

- xExchange Crash Course: [https://www.youtube.com/watch?v=2WMIUTX-TrY](https://www.youtube.com/watch?v=2WMIUTX-TrY)

Advanced learning:

- xExchange V3 release notes: [https://agora.xexchange.com/t/xexchange-v3-release-notes/2029](https://agora.xexchange.com/t/xexchange-v3-release-notes/2029)
- Post-V3 release notes: [https://multiversx.notion.site/xExchange-Release-Notes-10c73522fb4d80898b19e8ad3c34a3d0](https://multiversx.notion.site/xExchange-Release-Notes-10c73522fb4d80898b19e8ad3c34a3d0)

- MEX 2.0 and XMEX explained: [https://www.youtube.com/watch?v=6gYMN2woAg8](https://youtu.be/2WMIUTX-TrY)
- Liquidity and LPing: [https://istarivision.medium.com/understanding-liquidity-and-liquidity-pools-4d4d3efa17a9](https://istarivision.medium.com/understanding-liquidity-and-liquidity-pools-4d4d3efa17a9)
- Initial MEX Distribution & Tokenomics: [https://xexchange.com/mex-economics-v2.pdf](https://xexchange.com/mex-economics-v2.pdf)
- NEW MEX Tokenomics: [https://xexchange.com/x-exchange-economics.pdf](https://xexchange.com/x-exchange-economics.pdf)
