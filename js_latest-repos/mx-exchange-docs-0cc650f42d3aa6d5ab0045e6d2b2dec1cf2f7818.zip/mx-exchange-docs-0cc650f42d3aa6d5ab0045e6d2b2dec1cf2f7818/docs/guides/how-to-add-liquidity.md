---
sidebar_position: 40
id: how-to-add-liquidity
sidebar_label: Add Liquidity
title: How to add liquidity
---

<div style={{ textAlign: 'center' }}>
    <img src="/docs/how-to/add-liquidity/home.png" alt="Add Liquidity Home" width="724" />
</div>

1. Log in to xExchange
2. Select “Earn” -> “Liquidity” from the top menu
3. Select your desired pool
4. Choose the type of position you want to open (Pool, Farm, Dual Farm)

<div style={{ textAlign: 'center' }}>
    <img src="/docs/how-to/add-liquidity/rewards-tier.png" alt="Add Liquidity Rewards Tier" width="724" />
</div>

5. Select the way you want to provide the liquidity

   You can provide an equal amount of both tokens (the classic way)

<div style={{ textAlign: 'center' }}>
    <img src="/docs/how-to/add-liquidity/two-tokens.png" alt="Add Liquidity Two Tokens" width="724" />
</div>

    Or you can do that using only one of the supported tokens (it does not have to be one of the pool's tokens) and the SC handles the conversion in the background

<div style={{ textAlign: 'center' }}>
    <img src="/docs/how-to/add-liquidity/one-token.png" alt="Add Liquidity One Token" width="724" />
</div>

6. Acknowledge the fee for withdrawing a Farm Position in the first 72 hours
7. Acknowledge the unbonding period of 9-10 days when withdrawing a Dual Farm Position
8. You will be asked to sign 1 or 2 transactions, as per your login method -> Confirm
9. The 1/2 transactions will be sent and your new balances will be automatically updated, pending the transactions’ execution
10. You can manage your positions on the Portfolio page
