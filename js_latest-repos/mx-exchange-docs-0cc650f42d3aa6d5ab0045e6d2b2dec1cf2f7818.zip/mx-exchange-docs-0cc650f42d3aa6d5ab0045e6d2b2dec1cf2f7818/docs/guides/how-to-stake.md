---
sidebar_position: 50
id: how-to-stake
sidebar_label: Stake
title: How to stake tokens
---

<div style={{ textAlign: 'center' }}>
    <img src="/docs/how-to/stake/home.png" alt="Staking Home" width="724" />
</div>

1. Log in to xExchange
2. Select “Earn” -> “Staking” from the top menu
3. Select your desired Staking farm
4. Select the way you want to provide the liquidity.

   You can provide the Staking farm's token (the classic way)

<div style={{ textAlign: 'center' }}>
    <img src="/docs/how-to/stake/farm-token.png" alt="Staking Farm Token" width="724" />
</div>

    Or you can provide a different token and the SC handles the conversion in the background

<div style={{ textAlign: 'center' }}>
    <img src="/docs/how-to/stake/any-token.png" alt="Staking Any Token" width="724" />
</div>

5. Acknowledge the unbonding period of 9-10 days when withdrawing
6. Click “Continue”
7. You will be asked to sign 1 or 2 transactions, as per your login method -> Confirm
8. The transaction(s) will be sent and your new balances will be automatically updated, pending the transactions’ execution
9. You can manage your positions on the Portfolio page
