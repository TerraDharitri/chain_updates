---
sidebar_position: 20
id: how-to-login
sidebar_label: Login
title: How to Login to xExchange
---

<div style={{ textAlign: 'center' }}>
    <img src="/docs/how-to/connect-wallet.png" alt="Connect Wallet" width="560" />
</div>

- **xPortal Mobile Wallet** - scan a QR code with your xPortal App and connect your xPortal wallet to the exchange. You can also connect to xExchange on mobile via the xPortal Discover section. Your xPortal App will then be used to sign all your actions on the exchange

- **MultiversX Wallet Extension** - on the web extension pop-up you can create or import multiple different wallets and connect to different networks, such as mainnet, testnet or devnet. You can securely switch between multiple wallets and sign messages or transfer funds.

- **Ledger** - use your Ledger hardware wallet to connect. You will be prompted to confirm actions taken on the exchange on your device

- **MultiversX** **Wallet** - you can login using a .JSON file + password. A new tab, only for the login process, will be opened with the familiar MultiversX Wallet
