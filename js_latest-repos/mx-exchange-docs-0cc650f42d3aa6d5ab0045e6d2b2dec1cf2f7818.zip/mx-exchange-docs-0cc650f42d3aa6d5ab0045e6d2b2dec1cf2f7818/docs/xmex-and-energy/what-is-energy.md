---
sidebar_position: 2
id: what-is-energy
sidebar_label: What is Energy?
title: What is Energy?
---

<img src="/docs/features/energy-header.webp" alt="xExchange Energy" />

Any xMEX has an amount of Energy proportional to the locked period.

1 xMEX fully locked for 4 years gives 1 Energy Point.

<div style={{ textAlign: 'center' }}>
    <img src="/docs/tokenomics/energy-periods.png" width="700" alt="Energy Periods" />
</div>

Example:

You own 1,000,000 xMEX, which are locked for 1 year (360 days).

You will start out with 1,000,000\*0.25 = 250,000 Energy and after each day, you will have 694.44 less Energy.

How is Energy calculated: **Energy** = **Amount** x **Charge**

**Amount** refers to the xMEX holdings

**Charge** is related to the duration that each xMEX is locked for (see table above)

The amount of an account’s Energy determines the rate of rewards for participating in xExchange.

Simply put, more Energy means more rewards & benefits:

- higher APR for farms
- higher APR for staking
- bigger portion of xExchange fees (a share of 5% of xMEX emissions, 0.05% of swap fees, Energy removal fees)
- Governance power
- other perks

Each day, as the xMEX gets closer to its unlock day, it will lose 0.000694 Energy points.

However, losing Energy does not mean you that you are losing xMEX tokens. The amount of xMEX stays the same. You are just losing Energy because your XMEX tokens are nearing their unlock date.

For a more in-depth look into the Energy system, check out the [xExchange Whitepaper](https://xexchange.com/x-exchange-economics.pdf).
