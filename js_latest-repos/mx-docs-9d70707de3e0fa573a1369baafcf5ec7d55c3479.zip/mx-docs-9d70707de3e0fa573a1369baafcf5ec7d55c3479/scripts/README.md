## Render notebooks

```
cd mx-docs
python3 ./scripts/render_notebooks.py
```

## Add bot markers

```
cd mx-docs
python3 ./scripts/add_bot_markers.py
```
