---
id: erdkotlin
title: Kotlin SDK
---

[comment]: # (mx-abstract)

MultiversX SDK for Kotlin

**erdkotlin** consists of Kotlin helpers and utilities for interacting with the Blockchain. 

The source code can be found here: [mx-sdk-erdkotlin](https://github.com/multiversx/mx-sdk-erdkotlin). For more details, follow [the documentation](https://github.com/multiversx/mx-sdk-erdkotlin).
