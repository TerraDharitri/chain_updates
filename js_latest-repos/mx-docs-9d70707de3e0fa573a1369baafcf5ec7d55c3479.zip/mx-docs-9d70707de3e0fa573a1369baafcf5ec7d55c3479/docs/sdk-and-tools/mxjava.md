---
id: mxjava
title: Java SDK
---

[comment]: # (mx-abstract)

MultiversX SDK for Java

**erdjava** consists of Java helpers and utilities for interacting with the Blockchain. The source code can be found here: [mx-sdk-erdjava](https://github.com/multiversx/mx-sdk-erdjava/).
