---
id: sdk-go
title: Go SDK
---

[comment]: # (mx-abstract)

## MultiversX SDK for Golang

**sdk-go** consists of Go helpers and utilities for interacting with the Blockchain. 

The source code be found here: [mx-sdk-go](https://github.com/multiversx/mx-sdk-go).
