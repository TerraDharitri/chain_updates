---
id: erdcpp
title: C++ SDK
---

[comment]: # (mx-abstract)

MultiversX SDK for C++

**erdcpp** consists of C++ helpers and utilities for interacting with the Blockchain. 

The source code be found here: [mx-sdk-erdcpp](https://github.com/multiversx/mx-sdk-erdcpp). For more details, follow [the documentation](https://github.com/multiversx/mx-sdk-erdcpp).
