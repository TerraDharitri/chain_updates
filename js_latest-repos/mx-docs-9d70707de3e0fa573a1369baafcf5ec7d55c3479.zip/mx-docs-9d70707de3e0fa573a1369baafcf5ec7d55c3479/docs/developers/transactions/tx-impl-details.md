---
id: tx-impl-details
title: Implementation details (TODO)
---

[comment]: # (mx-abstract)

Some less relevant implementation details relegated here. Should not be relevant to the average user.

[comment]: # (mx-context-auto)

## Annotations

- mandos
- their output
    - value
    - annotation
    
