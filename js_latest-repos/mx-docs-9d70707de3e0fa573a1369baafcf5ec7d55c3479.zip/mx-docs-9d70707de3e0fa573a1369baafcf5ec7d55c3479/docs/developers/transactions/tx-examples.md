---
id: tx-examples
title: Examples (TODO - not currently in sidebar)
---

[comment]: # (mx-abstract)



[comment]: # (mx-context-auto)

## Simpl tx

self.tx().....

