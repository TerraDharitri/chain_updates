---
id: nft-tokens
title: NFT tokens
---

The Semi-Fungible / Non-Fungible Tokens documentation has been moved [here](/tokens/nft-tokens).
