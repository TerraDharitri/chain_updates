---
id: system-delegation-events
title: System Delegation Events
---

