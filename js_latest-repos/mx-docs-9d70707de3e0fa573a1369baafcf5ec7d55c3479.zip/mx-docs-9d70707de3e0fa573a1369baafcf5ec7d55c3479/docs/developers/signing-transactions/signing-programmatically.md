---
id: signing-programmatically
title: Signing programmatically
---

In order to sign a transaction (or a message) using one of the SDKs, follow:

- [Signing objects using **sdk-js**](/sdk-and-tools/sdk-js/sdk-js-cookbook#signing-objects)
- [Signing objects using **sdk-py**](/sdk-and-tools/sdk-py#signing-objects)
