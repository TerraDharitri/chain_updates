---
id: esdt-tokens
title: ESDT tokens
---

The Fungible Tokens documentation has been moved [here](/tokens/fungible-tokens).
