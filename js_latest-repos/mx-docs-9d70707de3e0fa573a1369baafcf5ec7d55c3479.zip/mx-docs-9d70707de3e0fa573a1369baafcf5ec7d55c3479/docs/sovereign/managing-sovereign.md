# Managing Sovereign Chains

:::note
This version of the documentation focuses solely on the essential steps required to set up and deploy a sovereign chain on either a local or remote computer.  More content will be added as it is accepted and discussed on [Agora](https://agora.multiversx.com/), or once it is implemented and available for production.
:::

