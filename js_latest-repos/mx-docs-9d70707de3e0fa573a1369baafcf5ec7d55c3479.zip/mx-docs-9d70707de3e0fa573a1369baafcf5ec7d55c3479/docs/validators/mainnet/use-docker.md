---
id: use-docker
title: How to use the Docker Image
---

:::caution
This section is deprecated. We are now using the elrond-go-scripts unified script repo.
Check this section [Install a Mainnet/Testnet/Devnet Node](/validators/nodes-scripts/config-scripts) instead.
:::
