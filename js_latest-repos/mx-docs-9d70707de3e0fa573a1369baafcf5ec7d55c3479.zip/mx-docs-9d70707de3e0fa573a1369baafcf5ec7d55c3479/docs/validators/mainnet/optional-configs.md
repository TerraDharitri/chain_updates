---
id: optional-configs
title: Optional Configurations
---

:::caution
This section is deprecated. We are now using the elrond-go-scripts unified script repo.
Check this section [Install a Mainnet/Testnet/Devnet Node](/validators/nodes-scripts/config-scripts) instead.
:::
