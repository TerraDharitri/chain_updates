---
id: staking-unstaking-unjailing
title: Staking, unstaking and unjailing
---

The content of this page was moved to [Staking & Unstaking](/validators/staking) and [Unjailing](/validators/staking/unjailing).
