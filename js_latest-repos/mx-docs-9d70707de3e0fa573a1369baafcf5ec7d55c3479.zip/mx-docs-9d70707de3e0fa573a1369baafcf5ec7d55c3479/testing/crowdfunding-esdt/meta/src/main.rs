fn main() {
    multiversx_sc_scenario::meta::perform::<crowdfunding::AbiProvider>();
}
