# wasm-vm-executor-rs

VM wasmer 2.2 executor + specialized C API to be used from Go.

Call `make capi` in the root to get the binary and the C header.
