mod test_instance;
mod test_wat;
mod test_wat_bad;

pub use test_instance::*;
pub use test_wat::*;
pub use test_wat_bad::*;
