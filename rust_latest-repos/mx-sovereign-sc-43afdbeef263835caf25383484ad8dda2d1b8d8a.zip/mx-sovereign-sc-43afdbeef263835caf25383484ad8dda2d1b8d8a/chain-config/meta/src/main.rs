fn main() {
    multiversx_sc_meta_lib::cli_main::<chain_config::AbiProvider>();
}
