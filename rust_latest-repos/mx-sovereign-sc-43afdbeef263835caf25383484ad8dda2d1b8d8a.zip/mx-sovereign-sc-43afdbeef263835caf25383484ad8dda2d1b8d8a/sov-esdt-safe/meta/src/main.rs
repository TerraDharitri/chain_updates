fn main() {
    multiversx_sc_meta_lib::cli_main::<sov_esdt_safe::AbiProvider>();
}
