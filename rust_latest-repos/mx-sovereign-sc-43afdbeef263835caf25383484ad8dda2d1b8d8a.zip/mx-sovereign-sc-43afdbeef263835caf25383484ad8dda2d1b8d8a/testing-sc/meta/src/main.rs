fn main() {
    multiversx_sc_meta_lib::cli_main::<testing_sc::AbiProvider>();
}
