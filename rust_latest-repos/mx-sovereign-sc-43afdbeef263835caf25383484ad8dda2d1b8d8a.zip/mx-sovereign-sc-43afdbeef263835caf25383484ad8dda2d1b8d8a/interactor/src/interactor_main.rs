
use multiversx_sc_snippets::imports::*;
use rust_interact::mvx_esdt_safe_cli;

#[tokio::main]
async fn main() {
    mvx_esdt_safe_cli().await;
}  

