fn main() {
    multiversx_sc_meta::cli_main::<router_mock::AbiProvider>();
}
