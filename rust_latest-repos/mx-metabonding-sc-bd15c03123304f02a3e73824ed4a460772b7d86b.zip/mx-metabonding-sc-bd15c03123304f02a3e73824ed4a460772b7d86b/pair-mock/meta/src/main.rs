fn main() {
    multiversx_sc_meta::cli_main::<pair_mock::AbiProvider>();
}
