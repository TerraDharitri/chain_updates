fn main() {
    multiversx_sc_meta::cli_main::<nft_minter_deployer::AbiProvider>();
}
