fn main() {
    multiversx_sc_meta::cli_main::<royalties_handler::AbiProvider>();
}
