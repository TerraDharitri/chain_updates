# Smart contract for the legacy delegation

The delegation contract holds and stakes delegators' funds to the MultiversX Community Nodes. 
