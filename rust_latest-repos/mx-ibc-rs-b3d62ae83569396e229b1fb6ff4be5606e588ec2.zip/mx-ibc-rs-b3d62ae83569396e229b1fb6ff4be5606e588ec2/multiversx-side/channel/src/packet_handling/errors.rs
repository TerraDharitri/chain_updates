pub static UNEXPECTED_PACKET_SOURCE_ERR_MSG: &[u8] = b"Unexpected packet source";
pub static PACKET_ALREADY_PROCESSED_ERR_MSG: &[u8] =
    b"Channel packet already processed in prev upgrade";
pub static UNEXPECTED_PACKET_DEST_ERR_MSG: &[u8] = b"Unexpected packet destination";
pub static PACKET_COMM_MISMATCH_ERR_MSG: &[u8] = b"Packet commitment mismatch";
pub static UNKNOW_CHANNEL_ORDER_ERR_MSG: &[u8] = b"Unknown channel order";
