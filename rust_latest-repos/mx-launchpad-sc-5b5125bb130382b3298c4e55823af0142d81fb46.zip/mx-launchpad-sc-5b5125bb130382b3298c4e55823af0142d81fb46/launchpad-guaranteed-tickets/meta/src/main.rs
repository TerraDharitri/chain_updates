fn main() {
    multiversx_sc_meta_lib::cli_main::<launchpad_guaranteed_tickets::AbiProvider>();
}
