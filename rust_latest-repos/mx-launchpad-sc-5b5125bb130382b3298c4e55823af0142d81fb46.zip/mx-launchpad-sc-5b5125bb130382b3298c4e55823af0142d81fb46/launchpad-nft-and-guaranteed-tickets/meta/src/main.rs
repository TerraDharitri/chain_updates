fn main() {
    multiversx_sc_meta_lib::cli_main::<launchpad_nft_and_guaranteed_tickets::AbiProvider>();
}
