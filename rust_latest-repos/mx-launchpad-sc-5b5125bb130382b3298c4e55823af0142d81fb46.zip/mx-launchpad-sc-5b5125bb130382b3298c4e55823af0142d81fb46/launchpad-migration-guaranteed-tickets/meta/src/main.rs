fn main() {
    multiversx_sc_meta_lib::cli_main::<launchpad_migration_guaranteed_tickets::AbiProvider>();
}
