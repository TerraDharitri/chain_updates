fn main() {
    multiversx_sc_meta_lib::cli_main::<permissions_hub::AbiProvider>();
}
