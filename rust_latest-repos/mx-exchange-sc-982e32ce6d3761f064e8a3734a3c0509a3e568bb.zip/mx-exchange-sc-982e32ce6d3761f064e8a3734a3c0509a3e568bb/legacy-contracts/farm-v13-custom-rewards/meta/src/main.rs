fn main() {
    multiversx_sc_meta_lib::cli_main::<farm_v13_custom_rewards::AbiProvider>();
}
