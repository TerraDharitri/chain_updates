fn main() {
    multiversx_sc_meta_lib::cli_main::<metabonding_staking_legacy::AbiProvider>();
}
