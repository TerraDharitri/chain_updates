fn main() {
    multiversx_sc_meta_lib::cli_main::<locked_asset_distribution::AbiProvider>();
}
