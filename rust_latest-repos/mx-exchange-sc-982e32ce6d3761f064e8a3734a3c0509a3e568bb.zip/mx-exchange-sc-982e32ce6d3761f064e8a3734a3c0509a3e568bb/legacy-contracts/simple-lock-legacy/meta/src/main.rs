fn main() {
    multiversx_sc_meta_lib::cli_main::<simple_lock_legacy::AbiProvider>();
}
