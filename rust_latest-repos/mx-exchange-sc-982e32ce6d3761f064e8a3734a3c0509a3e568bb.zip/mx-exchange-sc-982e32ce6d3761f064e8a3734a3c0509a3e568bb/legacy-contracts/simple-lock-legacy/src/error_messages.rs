pub static NO_PAYMENT_ERR_MSG: &[u8] = b"No payment";
pub static CANNOT_UNLOCK_YET_ERR_MSG: &[u8] = b"Cannot unlock yet";
