mod rc_new_cyclic_fallible;

pub use rc_new_cyclic_fallible::rc_new_cyclic_fallible;
