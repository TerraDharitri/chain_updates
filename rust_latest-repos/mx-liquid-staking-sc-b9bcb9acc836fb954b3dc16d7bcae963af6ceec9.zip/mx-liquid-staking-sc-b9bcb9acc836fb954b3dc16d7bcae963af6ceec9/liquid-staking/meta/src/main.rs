fn main() {
    multiversx_sc_meta_lib::cli_main::<liquid_staking::AbiProvider>();
}
