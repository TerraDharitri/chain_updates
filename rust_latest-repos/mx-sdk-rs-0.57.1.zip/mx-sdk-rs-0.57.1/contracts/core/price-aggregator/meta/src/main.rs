fn main() {
    multiversx_sc_meta_lib::cli_main::<multiversx_price_aggregator_sc::AbiProvider>();
}
