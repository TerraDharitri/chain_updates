fn main() {
    multiversx_sc_meta_lib::cli_main::<multiversx_wegld_swap_sc::AbiProvider>();
}
