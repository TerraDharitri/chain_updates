# EGLD-WEGLD swap

## Overview

The EGLD-WEGLD swap contract mints and distributes the WEGLD token, in equal amount to the amount of EGLD locked in the contract.

There are such contracts deployed in each shard.
