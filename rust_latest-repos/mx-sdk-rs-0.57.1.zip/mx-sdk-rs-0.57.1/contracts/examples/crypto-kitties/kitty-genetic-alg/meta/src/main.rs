fn main() {
    multiversx_sc_meta_lib::cli_main::<kitty_genetic_alg::AbiProvider>();
}
