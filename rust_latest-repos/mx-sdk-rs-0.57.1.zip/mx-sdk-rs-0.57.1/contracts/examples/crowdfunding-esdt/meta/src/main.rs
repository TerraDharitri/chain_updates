fn main() {
    multiversx_sc_meta_lib::cli_main::<crowdfunding_esdt::AbiProvider>();
}
