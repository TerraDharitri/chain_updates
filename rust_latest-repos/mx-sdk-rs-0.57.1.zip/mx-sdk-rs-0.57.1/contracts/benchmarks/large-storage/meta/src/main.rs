fn main() {
    multiversx_sc_meta_lib::cli_main::<large_storage::AbiProvider>();
}
