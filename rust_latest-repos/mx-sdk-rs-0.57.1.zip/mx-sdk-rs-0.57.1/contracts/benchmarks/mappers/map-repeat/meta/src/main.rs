fn main() {
    multiversx_sc_meta_lib::cli_main::<map_repeat::AbiProvider>();
}
