fn main() {
    multiversx_sc_meta_lib::cli_main::<linked_list_repeat::AbiProvider>();
}
