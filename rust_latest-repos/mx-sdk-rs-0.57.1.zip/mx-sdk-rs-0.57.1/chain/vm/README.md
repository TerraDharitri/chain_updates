# MultiversX VM implementation in Rust

This crate puts forth a partial implementation of the MultiversX blockchain VM.

It is designed for testing and debugging smart contracts, but it could in principle evolve to become part of other tools too.
