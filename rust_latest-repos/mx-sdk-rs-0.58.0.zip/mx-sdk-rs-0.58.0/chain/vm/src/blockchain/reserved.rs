pub const STORAGE_RESERVED_PREFIX: &[u8] = b"ELROND";

pub const STORAGE_REWARD_KEY: &[u8] = b"ELRONDreward";
