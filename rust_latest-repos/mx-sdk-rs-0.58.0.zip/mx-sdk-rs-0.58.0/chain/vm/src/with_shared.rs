#![allow(deprecated)]

mod shareable;
mod with_shared_mut_ref;

pub use shareable::Shareable;
pub use with_shared_mut_ref::with_shared_mut_ref;
