## Core contracts

The code for some of the most important and commonly used contracts can be found here. They are central to the ecosystem and will likely be used as part of many dApps.

They are released on crates.io, in order to be used as part of tests, contract calls and snippets.
