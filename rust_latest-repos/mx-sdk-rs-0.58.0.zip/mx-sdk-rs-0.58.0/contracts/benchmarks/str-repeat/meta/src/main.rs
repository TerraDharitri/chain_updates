fn main() {
    multiversx_sc_meta_lib::cli_main::<str_repeat::AbiProvider>();
}
