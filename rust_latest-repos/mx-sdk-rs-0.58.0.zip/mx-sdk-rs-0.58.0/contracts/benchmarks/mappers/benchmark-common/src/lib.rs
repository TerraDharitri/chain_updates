#![no_std]

mod benchmark_common;
mod example_struct;

pub use crate::{benchmark_common::*, example_struct::ExampleStruct};
