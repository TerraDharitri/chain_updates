# Adder

`Adder` is a simple Smart Contract.
