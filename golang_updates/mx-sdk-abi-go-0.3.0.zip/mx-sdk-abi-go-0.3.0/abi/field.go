package abi

// Field is a field in a struct, enum etc.
type Field struct {
	Name  string
	Value SingleValue
}
