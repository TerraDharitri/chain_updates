package abi

const trueAsByte = uint8(1)
const falseAsByte = uint8(0)
const optionMarkerForAbsentValue = uint8(0)
const optionMarkerForPresentValue = uint8(1)
const pubKeyLength = 32
