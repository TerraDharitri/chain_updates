# mx-sdk-abi-go

ABI components and ABI-aware codecs for interacting with MultiversX smart contracts (using Go).
