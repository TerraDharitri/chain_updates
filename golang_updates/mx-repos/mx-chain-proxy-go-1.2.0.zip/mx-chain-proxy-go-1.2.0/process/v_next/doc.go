// Package v_next represents the processors needed for the example version v_next of the API
package v_next
