// Package v1.0 represents the processors needed for the version v1.0 of the API
package v1_0
