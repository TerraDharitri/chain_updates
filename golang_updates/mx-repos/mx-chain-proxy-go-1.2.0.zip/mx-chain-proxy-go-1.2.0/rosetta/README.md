## Multiversx Rosetta

Moved at [Multiversx/rosetta](https://github.com/multiversx/mx-chain-rosetta).
