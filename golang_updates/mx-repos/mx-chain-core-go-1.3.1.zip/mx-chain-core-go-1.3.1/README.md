# mx-chain-core-go

mx-chain-go common components and data that can be used in other repositories as well
