package process

import "errors"

var (
	errNilChainSimulator = errors.New("nil chain simulator")
	errInvalidValue      = errors.New("invalid value")
)
