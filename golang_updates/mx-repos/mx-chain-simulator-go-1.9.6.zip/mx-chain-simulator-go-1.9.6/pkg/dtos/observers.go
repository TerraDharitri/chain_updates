package dtos

// ObserverInfo is the dto that contains information about an observer
type ObserverInfo struct {
	APIPort int `json:"api-port"`
}
