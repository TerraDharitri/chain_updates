package process

const (
	accountsIndex = "accounts-000001"
)
