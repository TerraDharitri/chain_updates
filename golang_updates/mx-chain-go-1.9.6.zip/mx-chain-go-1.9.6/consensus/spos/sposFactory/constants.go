package sposFactory

const blsConsensusType = "bls"
const maxDelayCacheSize = 20
