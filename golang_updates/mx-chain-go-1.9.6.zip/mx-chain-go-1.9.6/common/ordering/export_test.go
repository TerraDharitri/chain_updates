package ordering

func GetNilOrderedCollection() *orderedCollection {
	return nil
}
