package enablers

import "errors"

var errMissingRoundActivation = errors.New("missing round activation definition")
