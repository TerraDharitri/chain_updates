package integrationtests

const (
	//nolint
	testNumOfShards = 3
	//nolint
	esURL = "http://localhost:9200"
	//nolint
	addressPrefix = "erd"
)
