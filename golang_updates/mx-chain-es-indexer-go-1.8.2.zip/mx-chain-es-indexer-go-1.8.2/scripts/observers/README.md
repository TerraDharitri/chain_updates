## Prerequisites

```
pip3 install -r ./requirements.txt
```