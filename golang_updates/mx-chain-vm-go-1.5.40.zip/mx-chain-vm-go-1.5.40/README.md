# wasm-vm

[![](https://img.shields.io/badge/made%20by-MultiversX-blue.svg)](http://multiversx.com/)
![Build](https://github.com/multiversx/mx-chain-vm-go/actions/workflows/build-test.yml/badge.svg?branch=master)
[![Go Report Card](https://goreportcard.com/badge/github.com/multiversx/mx-chain-vm-go)](https://goreportcard.com/report/github.com/multiversx/mx-chain-vm-go)
[![LoC](https://tokei.rs/b1/github/multiversx/mx-chain-vm-go?category=code)](https://github.com/multiversx/mx-chain-vm-go)
[![codecov](https://codecov.io/gh/multiversx/mx-chain-vm-go/branch/master/graph/badge.svg?token=MYS5EDASOJ)](https://codecov.io/gh/multiversx/mx-chain-vm-go)

WASM-based Virtual Machine for running MultiversX Smart Contracts.
