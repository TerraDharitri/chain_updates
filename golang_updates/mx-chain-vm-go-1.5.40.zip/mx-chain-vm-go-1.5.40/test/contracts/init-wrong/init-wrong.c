void init(int a) {
	a = a + 1;
}
