#ifndef _TYPES_H_
#define _TYPES_H_

typedef unsigned char byte;
typedef long long i64;
typedef unsigned int u32;
typedef int i32;
typedef unsigned long long u64;
typedef long long i64;

#endif
