#include "../mxvm/context.h"
#include "../mxvm/bigInt.h"

void bar() {
   int64finish(42);
}
