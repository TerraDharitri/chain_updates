#include "../mxvm/context.h"

void init() {}

void answer() {
	int64finish(42);
}
