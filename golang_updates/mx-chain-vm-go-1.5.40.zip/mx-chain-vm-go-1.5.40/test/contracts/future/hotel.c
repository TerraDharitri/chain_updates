#include "../mxvm/context.h"

void init() {}

void bookHotel() {}

void cancelHotel() {}
