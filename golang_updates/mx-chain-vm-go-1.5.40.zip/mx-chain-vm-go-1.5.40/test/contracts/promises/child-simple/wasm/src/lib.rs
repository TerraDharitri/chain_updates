#![no_std]

pub use child_simple::*;

