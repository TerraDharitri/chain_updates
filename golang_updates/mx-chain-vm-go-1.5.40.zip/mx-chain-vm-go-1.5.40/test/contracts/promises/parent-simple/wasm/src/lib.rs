#![no_std]

pub use parent_simple::*;

