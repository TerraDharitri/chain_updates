#![no_std]

pub use second_contract::*;

