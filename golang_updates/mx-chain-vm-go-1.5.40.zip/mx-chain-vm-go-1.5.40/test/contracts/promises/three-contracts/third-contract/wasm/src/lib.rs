#![no_std]

pub use third_contract::*;

