#![no_std]

pub use first_contract::*;

