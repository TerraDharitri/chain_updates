export * from './ScrDetailItem';
