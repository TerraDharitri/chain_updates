export * from './ConfirmAmountLabel';
