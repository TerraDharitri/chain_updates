export * from './mockOperaProvider';
