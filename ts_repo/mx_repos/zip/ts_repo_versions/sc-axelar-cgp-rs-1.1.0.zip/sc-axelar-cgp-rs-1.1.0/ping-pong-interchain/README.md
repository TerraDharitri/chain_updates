# Ping Pong Interchain Contract

An example contract used mainly in tests that can be called cross-chain.

It is a variant of the [Ping Pong](https://github.com/multiversx/mx-contracts-rs/tree/main/contracts/ping-pong-egld) MultiversX example contract,
that also implements the endpoints **executeWithInterchainToken** and **expressExecuteWithInterchainToken** so it can be called cross-chain by the ITS (Interchain Token Service) contract.
