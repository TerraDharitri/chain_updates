export { configSlice } from './configSlice';
