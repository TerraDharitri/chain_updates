export * from './CrossWindowProviderStrategy';
