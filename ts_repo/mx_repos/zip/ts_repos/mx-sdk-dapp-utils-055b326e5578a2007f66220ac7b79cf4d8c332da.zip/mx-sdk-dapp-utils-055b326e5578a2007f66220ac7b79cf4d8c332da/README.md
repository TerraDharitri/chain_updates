# mx-sdk-dapp-utils

This package provides a set of utilities and models for dApp development.

## Distribution

[npm](https://www.npmjs.com/package/@multiversx/sdk-dapp-utils)

## Installation

`sdk-dapp-utils` is delivered via [npm](https://www.npmjs.com/package/@multiversx/sdk-dapp-utils), therefore it can be installed as follows:

```
npm install @multiversx/sdk-dapp-utils
```

### Building the library

In order to compile the library, run the following:

```
npm install
npm run compile
```
