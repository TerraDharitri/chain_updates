declare module "*.svg" {
  import { Component } from "solid-js";
  const content: Component<any>;
  export default content;
}
