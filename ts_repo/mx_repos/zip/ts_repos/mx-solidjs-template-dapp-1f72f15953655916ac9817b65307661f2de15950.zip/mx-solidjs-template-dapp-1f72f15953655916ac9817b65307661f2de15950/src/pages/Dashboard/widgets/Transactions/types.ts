export interface TransactionsPropsType {
  receiver?: string;
}
