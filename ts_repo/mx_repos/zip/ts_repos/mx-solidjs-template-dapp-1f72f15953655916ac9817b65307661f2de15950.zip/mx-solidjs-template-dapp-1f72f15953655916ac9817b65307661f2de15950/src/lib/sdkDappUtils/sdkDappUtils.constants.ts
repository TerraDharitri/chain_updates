export { DIGITS, DECIMALS } from '@multiversx/sdk-dapp-utils/out/constants';
