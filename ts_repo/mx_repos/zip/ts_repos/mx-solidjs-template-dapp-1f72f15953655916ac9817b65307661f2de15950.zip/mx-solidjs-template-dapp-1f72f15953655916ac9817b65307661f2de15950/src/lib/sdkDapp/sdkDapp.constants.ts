export {
  ACCOUNTS_ENDPOINT,
  TRANSACTIONS_ENDPOINT
} from '@multiversx/sdk-dapp/out/apiCalls/endpoints';
export {
  GAS_LIMIT,
  GAS_PRICE
} from '@multiversx/sdk-dapp/out/constants/mvx.constants';
