export interface AccountHistory {
  address: string;
  timestamp: number;
  balance: string;
}
