export class ProviderDelegators {
  contract: string = '';
  address: string = '';
  activeStake: string = '';
  activeStakeNum: number = 0;
  timestamp: number = 0;
}
