export interface LockedTokensInterface {
  xmex: string,
  lkmex: string;
}
