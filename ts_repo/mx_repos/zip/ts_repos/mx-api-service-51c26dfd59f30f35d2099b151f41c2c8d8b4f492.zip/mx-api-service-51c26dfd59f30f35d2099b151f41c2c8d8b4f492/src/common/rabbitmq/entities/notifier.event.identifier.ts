export enum NotifierEventIdentifier {
  ESDTNFTCreate = 'ESDTNFTCreate',
  ESDTNFTUpdateAttributes = 'ESDTNFTUpdateAttributes',
  transferOwnership = 'transferOwnership',
}
