export class LogMetricsEvent {
  args!: any[];
}
