export enum TransactionActionCategory {
  esdtNft = 'esdtNft',
  mex = 'mex',
  stake = 'stake',
  scCall = 'scCall',
  scDeploy = 'scDeploy',
}
