export enum TransactionBatchStatus {
  pending = 'pending',
  success = 'success',
  invalid = 'invalid',
  dropped = 'dropped',
}
