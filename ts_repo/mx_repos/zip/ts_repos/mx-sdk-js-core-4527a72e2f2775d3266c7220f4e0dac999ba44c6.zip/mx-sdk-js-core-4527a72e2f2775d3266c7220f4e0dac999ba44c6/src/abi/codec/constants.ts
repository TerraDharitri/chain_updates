export const SizeOfU32 = 4;
