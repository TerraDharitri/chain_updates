import { NetworkType } from 'types/network.types';

export interface NetworkSliceType {
  network: NetworkType;
}
