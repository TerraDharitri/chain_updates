// types here need to be synced with the types in sdk-dapp-core-ui
export enum PendingTransactionsEventsEnum {
  CLOSE_PENDING_TRANSACTIONS = 'CLOSE_PENDING_TRANSACTIONS',
  OPEN_PENDING_TRANSACTIONS_PANEL = 'OPEN_PENDING_TRANSACTIONS_PANEL',
  DATA_UPDATE = 'DATA_UPDATE'
}
