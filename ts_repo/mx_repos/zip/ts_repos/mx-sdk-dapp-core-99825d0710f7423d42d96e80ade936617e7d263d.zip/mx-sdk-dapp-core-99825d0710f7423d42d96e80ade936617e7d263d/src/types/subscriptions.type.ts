export enum SubscriptionsEnum {
  websocketStatusChanged = 'websocketStatusChanged',
  websocketEventReceived = 'websocketEventReceived',
  websocketCleanup = 'websocketCleanup'
}
