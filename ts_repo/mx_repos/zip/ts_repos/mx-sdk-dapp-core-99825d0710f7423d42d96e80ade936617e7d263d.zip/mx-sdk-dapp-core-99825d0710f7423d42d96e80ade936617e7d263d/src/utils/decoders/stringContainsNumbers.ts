export const stringContainsNumbers = (str: string) => /\d/.test(str);
