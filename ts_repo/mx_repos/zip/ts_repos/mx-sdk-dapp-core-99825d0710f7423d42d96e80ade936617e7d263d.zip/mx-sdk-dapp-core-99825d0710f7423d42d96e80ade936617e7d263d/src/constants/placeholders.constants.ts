/**
 * Not Applicable
 * @value N/A
 */
export const N_A = 'N/A';
export const ELLIPSIS = '...';
export const EMPTY_PPU = 0;
