export { IframeProvider } from '@multiversx/sdk-web-wallet-iframe-provider/out';
