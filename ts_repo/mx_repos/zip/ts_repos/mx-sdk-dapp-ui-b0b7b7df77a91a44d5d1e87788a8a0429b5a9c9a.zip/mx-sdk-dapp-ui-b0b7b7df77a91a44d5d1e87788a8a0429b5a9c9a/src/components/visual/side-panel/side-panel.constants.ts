export const ANIMATION_DELAY_PROMISE = new Promise(resolve => setTimeout(resolve, 300));
