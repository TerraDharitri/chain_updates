// types here need to be synced with the types in sdk-dapp pendingTransactions.types.ts
export enum PendingTransactionsEventsEnum {
  CLOSE = 'CLOSE_PENDING_TRANSACTIONS',
  DATA_UPDATE = 'DATA_UPDATE_PENDING_TRANSACTIONS',
}
