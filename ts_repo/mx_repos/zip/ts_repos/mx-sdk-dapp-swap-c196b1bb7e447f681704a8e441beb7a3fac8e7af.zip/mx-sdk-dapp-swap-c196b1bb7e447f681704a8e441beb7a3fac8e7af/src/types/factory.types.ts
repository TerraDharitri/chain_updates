export interface FactoryType {
  defaultSlippage: number;
  slippageValues: number[];
  minSlippage: number;
  maxSlippage: number;
  minSwapAmount: number;
}
