export enum SwapGraphQLAddressEnum {
  MAINNET_API_ADDRESS = 'https://graph.xexchange.com/graphql',
  DEVNET_API_ADDRESS = 'https://devnet-graph.xexchange.com/graphql',
  TESTNET_API_ADDRESS = 'https://testnet-graph.xexchange.com/graphql',
  STAGING_API_ADDRESS = 'https://staging-graph.xexchange.com/graphql'
}
