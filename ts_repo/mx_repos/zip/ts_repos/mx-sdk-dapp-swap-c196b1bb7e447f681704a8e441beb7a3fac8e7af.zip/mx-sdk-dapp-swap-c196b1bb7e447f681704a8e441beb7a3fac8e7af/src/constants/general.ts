export const FIXED_INPUT = 0;
export const FIXED_OUTPUT = 1;
export const EGLD_IDENTIFIER = 'EGLD';
export const DIGITS = 4;
export const MIN_EGLD_DUST = '10000000000000000'; // 0.01 EGLD
export const POLLING_INTERVAL = 6000; // 6 seconds
