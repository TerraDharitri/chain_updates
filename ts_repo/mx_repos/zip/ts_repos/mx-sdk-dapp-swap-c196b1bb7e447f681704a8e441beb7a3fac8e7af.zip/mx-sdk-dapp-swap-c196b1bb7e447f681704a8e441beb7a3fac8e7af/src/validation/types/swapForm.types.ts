import { SwapRouteType } from 'types';

export type SwapFormType = {
  firstAmount: string;
  secondAmount: string;
  activeRoute: SwapRouteType;
};
