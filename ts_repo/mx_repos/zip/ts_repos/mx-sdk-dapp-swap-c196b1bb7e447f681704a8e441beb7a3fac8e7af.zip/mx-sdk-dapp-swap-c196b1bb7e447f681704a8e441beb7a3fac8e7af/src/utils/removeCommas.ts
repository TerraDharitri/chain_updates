export const removeCommas = (amount: string) => amount.replace(/,/g, '');
