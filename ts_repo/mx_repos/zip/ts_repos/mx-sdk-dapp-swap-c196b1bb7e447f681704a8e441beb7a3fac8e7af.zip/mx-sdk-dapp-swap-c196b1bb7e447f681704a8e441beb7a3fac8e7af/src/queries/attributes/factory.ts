export const factoryAttributes = `
  defaultSlippage
  slippageValues
  minSlippage
  maxSlippage
  minSwapAmount
`;
