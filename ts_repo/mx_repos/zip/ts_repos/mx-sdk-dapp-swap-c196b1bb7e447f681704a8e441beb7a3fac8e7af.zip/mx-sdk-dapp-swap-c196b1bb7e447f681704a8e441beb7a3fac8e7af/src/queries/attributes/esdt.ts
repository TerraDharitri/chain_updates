export const esdtAttributes = `
  balance
  decimals
  name
  identifier
  ticker
  owner
  assets {
    website
    description
    status
    pngUrl
    svgUrl
  }
  price
  type
  previous24hPrice
  previous7dPrice 
`;
