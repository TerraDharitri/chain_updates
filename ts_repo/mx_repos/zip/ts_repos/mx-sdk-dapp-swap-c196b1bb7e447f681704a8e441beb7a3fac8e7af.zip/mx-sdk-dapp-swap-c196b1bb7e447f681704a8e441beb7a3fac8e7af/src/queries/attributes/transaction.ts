export const transactionAttributes = `
  value
  receiver
  gasPrice
  gasLimit
  data
  chainID
  version
`;
