export const collectionAttributes = `
  assets {
    website
    description
    status
    pngUrl
    svgUrl
  }
  decimals
  name
  collection
  ticker
`;
