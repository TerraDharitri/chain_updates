export {
  GAS_LIMIT,
  GAS_PRICE,
  VERSION,
  GAS_PER_DATA_BYTE,
  GAS_PRICE_MODIFIER,
  fallbackNetworkConfigurations
} from '@multiversx/sdk-dapp/out/constants';
