export { getStore } from '@multiversx/sdk-dapp/out/store/store';
export { accountSelector } from '@multiversx/sdk-dapp/out/store/selectors/accountSelectors';
