export { EnvironmentsEnum } from '@multiversx/sdk-dapp/out/types/enums.types';
