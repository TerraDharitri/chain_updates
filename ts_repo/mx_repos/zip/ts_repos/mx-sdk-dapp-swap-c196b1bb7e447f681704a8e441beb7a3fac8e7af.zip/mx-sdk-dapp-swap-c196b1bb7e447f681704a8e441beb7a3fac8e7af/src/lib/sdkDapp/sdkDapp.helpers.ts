export { isStringBase64 } from '@multiversx/sdk-dapp/out/utils/decoders/base64Utils';
