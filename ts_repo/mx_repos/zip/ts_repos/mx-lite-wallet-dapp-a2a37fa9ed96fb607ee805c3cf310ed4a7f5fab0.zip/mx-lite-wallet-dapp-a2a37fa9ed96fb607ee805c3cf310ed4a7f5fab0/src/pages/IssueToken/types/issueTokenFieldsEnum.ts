export enum IssueTokenFieldsEnum {
  tokenName = 'tokenName',
  tokenTicker = 'tokenTicker',
  numDecimals = 'numDecimals',
  mintedValue = 'mintedValue'
}
