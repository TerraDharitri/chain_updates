export enum HookStateEnum {
  valid = 'valid',
  invalid = 'invalid',
  pending = 'pending'
}
