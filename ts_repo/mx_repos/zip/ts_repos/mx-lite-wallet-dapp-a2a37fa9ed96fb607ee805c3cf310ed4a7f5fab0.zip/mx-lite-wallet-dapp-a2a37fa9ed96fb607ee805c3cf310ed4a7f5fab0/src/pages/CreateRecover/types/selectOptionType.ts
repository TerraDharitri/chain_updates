export interface SelectOptionType {
  label: string;
  value: string;
}
