export interface WordType {
  content: string;
  id: number;
}
