export const isChromeIOS = () => navigator.userAgent.match('CriOS');
