export enum IssueCollectionFieldsEnum {
  tokenName = 'tokenName',
  tokenTicker = 'tokenTicker',
  tokenType = 'tokenType'
}
