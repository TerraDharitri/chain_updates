export enum IssueNftFieldsEnum {
  collection = 'collection',
  imageUrl = 'imageUrl',
  name = 'name',
  quantity = 'quantity',
  royalties = 'royalties'
}
