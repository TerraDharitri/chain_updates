// eslint-disable-next-line @typescript-eslint/no-var-requires
const createVersionFile = require('./createVersionFile');

createVersionFile();
