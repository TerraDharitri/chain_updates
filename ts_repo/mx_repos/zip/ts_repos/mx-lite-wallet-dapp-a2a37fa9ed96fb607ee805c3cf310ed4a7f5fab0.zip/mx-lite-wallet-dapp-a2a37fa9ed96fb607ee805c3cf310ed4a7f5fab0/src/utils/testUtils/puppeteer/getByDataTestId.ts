export const getByDataTestId = (dataTestId: string) =>
  `[data-testid="${dataTestId}"]`;
