export interface GetNftsType {
  address: string;
  search?: string;
  page?: number;
  size?: number;
}
