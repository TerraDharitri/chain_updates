export enum SendTypeEnum {
  esdt = 'ESDT',
  nft = 'NFT'
}

export interface TokenOptionType {
  label: string;
  value: string;
}
