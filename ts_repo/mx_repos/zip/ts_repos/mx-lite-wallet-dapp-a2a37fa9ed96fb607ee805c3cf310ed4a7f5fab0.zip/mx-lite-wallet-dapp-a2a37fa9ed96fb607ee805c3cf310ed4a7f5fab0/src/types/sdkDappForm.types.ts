export type { TokenType } from '@multiversx/sdk-dapp/types/tokens.types';
export type { PartialNftType } from '@multiversx/sdk-dapp-form/types/tokens';
