export enum SearchParamsEnum {
  tokenId = 'tokenId',
  isNFT = 'isNFT'
}
