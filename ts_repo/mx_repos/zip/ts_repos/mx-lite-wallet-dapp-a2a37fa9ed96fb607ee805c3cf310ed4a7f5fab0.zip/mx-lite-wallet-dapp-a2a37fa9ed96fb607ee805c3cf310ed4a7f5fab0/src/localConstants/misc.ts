export const WALLET_FILE_NAME = 'fileName';
export const WALLET_FILE = 'walletFile';
export const MAX_ALLOWED_TRANSACTIONS_TO_SIGN = 5;
export const CUSTOM_TOAST_DEFAULT_DURATION = 5000;
export const SOVEREIGN_TRANSFER_GAS_LIMIT = 100_000_000;
export const ACCESS_TOKEN_KEY = 'accessToken';
