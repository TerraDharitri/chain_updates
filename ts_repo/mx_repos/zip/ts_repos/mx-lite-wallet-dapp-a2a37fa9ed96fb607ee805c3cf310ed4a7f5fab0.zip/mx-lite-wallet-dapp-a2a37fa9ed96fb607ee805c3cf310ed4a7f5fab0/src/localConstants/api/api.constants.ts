// Maximum API response of transactions, tokens, etc.
export const MAX_API_SIZE = 5000;
export const API_CACHE_DURATION_SECONDS = 0;
