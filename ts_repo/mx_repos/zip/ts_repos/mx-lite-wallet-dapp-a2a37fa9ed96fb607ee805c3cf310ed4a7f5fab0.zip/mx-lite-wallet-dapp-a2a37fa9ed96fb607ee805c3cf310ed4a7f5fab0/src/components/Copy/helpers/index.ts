export * from './readFromClipboard';
