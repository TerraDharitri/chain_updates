export const emptyWalletPassword = 'juxbit-7dusku-miskIs';
export const emptyWalletAccount = {
  address: 'erd1m7x4d8r6kj43082pew8cj5vhqhw3gtk6g99r044d4qxq08jpq6gs2trcrx',
  balance: '0',
  nonce: 0,
  timestamp: 0,
  shard: 1,
  txCount: 0,
  scrCount: 0,
  developerReward: '0'
};
