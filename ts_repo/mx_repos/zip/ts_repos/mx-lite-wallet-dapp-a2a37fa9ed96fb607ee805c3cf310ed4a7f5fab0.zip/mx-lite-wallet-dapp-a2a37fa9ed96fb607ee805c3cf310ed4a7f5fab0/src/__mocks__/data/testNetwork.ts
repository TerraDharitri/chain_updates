export const testNetwork = {
  apiAddress: 'https://api-sovereign-test.elrond.ro',
  extrasApiAddress: 'https://extras-api-sovereign-test.elrond.ro'
};
