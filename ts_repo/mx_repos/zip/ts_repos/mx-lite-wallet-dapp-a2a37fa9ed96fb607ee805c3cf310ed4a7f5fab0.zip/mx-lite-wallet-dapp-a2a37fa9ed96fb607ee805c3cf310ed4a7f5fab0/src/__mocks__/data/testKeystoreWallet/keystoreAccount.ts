export const keystoreAccount = {
  address: 'erd1q4teee5c32dw6dk2wg5hgcr356u0vqlewqjlzhk3d3chtzm2mnvsdmhppa',
  balance: '31455422924671253900800',
  developerReward: '0',
  nonce: 2529,
  rootHash: '/L9by9269E8qszvwRNU1nK6KRaR83qm5xYmZfOdI2no=',
  scrCount: 10,
  shard: 0,
  txCount: 10,
  username: 'webteam.elrond'
};
