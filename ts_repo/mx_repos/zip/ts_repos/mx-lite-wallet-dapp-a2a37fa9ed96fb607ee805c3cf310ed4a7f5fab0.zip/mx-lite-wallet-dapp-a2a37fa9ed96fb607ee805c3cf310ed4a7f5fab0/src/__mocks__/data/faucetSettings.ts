export const faucetSettings = {
  address: 'erd1xgzak3d6wcpyk83c3ne0n05khdz026e8p0rg8qu65dly706kfmxs0qecax',
  amount: '40000000000000000000',
  recaptchaBypass: true
};
