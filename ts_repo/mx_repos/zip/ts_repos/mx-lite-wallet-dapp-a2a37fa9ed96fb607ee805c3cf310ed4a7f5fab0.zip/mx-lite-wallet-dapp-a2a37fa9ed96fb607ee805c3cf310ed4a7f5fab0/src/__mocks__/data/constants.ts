export const WALLET_TARGET_ORIGIN = 'http://localhost';
export const WALLET_SOURCE_ORIGIN = 'https://localhost:3002';
export const MAIN_REFERRER = 'https://localhost:3001/';
export const DEFAULT_PAGE_LOAD_DELAY_MS = 1000;
export const DEFAULT_DELAY_MS = 100;
export const DEFAULT_PASSWORD = 'Zxcv789)';
