export const DEVNET_API = 'https://devnet-api.multiversx.com/';
export const MAIN_API = 'https://internal-api.multiversx.com/';
export const DEVNET_TOOLS_API = 'https://devnet-tools.multiversx.com/';
