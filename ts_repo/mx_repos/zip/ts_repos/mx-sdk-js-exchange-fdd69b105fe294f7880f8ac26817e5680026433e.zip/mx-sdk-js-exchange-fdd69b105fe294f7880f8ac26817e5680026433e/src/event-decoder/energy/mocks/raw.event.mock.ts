export const rawEnergyEvent = {
    identifier: 'lockTokens',
    address: 'erd1qqqqqqqqqqqqqpgq2anqkeemt2h5gzseusajuyxt2eaak3j50n4skqj5tz',
    data: 'AAAACA3gtrOnZAAAAAAAAAAAAAEAAAAIDeC2s6dkAAAAAAAIG8FtZ07IAAAAAAAAAAAAAgAAAAgbwW1nTsgAAA==',
    topics: [
        'ZW5lcmd5VXBkYXRlZA==',
        'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
        'AQ==',
        'AQ==',
        'Yys9jg==',
    ],
    order: 3,
};
