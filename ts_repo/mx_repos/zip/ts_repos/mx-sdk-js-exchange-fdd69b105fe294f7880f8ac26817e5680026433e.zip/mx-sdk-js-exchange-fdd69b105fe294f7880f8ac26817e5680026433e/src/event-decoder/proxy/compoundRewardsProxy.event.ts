import { RewardsProxyEvent } from './rewardsProxy.event';

export class CompoundRewardsProxyEvent extends RewardsProxyEvent {}
