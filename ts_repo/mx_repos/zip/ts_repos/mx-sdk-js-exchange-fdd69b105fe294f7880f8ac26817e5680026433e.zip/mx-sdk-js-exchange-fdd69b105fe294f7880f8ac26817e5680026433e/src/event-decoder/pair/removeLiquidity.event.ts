import { AddLiquidityEvent } from './addLiquidity.event';

export class RemoveLiquidityEvent extends AddLiquidityEvent {}
