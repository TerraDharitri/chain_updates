export type EsdtTokenPaymentType = {
    tokenIdentifier: string;
    tokenNonce: number;
    amount: string;
};
