export const EsdtTokenPaymentAttributesOld =
    'AAAAAApNRVgtZGMyODljAAAAAAAAAAAAAAAKTV4rYVjgfxuhgA==';
export const EsdtTokenPaymentAttributesNew =
    'AAAACk1FWC1kYzI4OWMAAAAAAAAAAAAAAApNXithWOB/G6GA';
