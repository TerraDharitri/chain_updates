export type WrappedLockedTokenType = {
    lockedTokenNonce: number;
};
