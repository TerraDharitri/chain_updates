# drt-sdk-js-guardians-provider

Co-Signing provider for dApps: Guardians Provider. 

<!-- Documentation is available on [docs.dharitri.org](https://docs.dharitri.org/sdk-and-tools/drtjs/drtjs-signing-providers/), while an integration example can be found [here](https://github.com/TerraDharitri/drt-sdk-js-examples/tree/main/signing-providers).

Note that **we recommend using [dapp-core](https://github.com/TerraDharitri/drt-sdk-dapp)** instead of integrating the signing provider on your own.

## Distribution

[npm](https://www.npmjs.com/package/@terradharitri/sdk-opera-provider)

## Installation

`sdk-opera-provider` is delivered via [npm](https://www.npmjs.com/package/@terradharitri/sdk-opera-provider), therefore it can be installed as follows:

```
npm install @terradharitri/sdk-opera-provider
```

### Building the library

In order to compile the library, run the following:

```
npm install
npm run compile
``` -->



