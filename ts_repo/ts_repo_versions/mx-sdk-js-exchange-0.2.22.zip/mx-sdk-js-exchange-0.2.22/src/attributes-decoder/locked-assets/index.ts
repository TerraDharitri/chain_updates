export * from './locked.asset.token';
