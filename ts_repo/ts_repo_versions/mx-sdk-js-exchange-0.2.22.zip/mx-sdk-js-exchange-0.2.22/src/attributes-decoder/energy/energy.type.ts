export type EnergyType = {
    amount: string;
    lastUpdateEpoch: number;
    totalLockedTokens: string;
};
