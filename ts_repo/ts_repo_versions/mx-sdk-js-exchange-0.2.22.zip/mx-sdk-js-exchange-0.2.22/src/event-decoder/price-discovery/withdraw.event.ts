import { DepositEvent } from './deposit.event';

export class WithdrawEvent extends DepositEvent {}
