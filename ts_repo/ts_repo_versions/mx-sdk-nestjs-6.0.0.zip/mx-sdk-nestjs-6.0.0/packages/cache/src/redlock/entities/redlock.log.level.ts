export enum RedlockLogLevel {
  NONE = 'none',
  WARNING = 'warning',
  ERROR = 'error',
}
