export declare const REDLOCK_TOKEN = "REDLOCK_TOKEN";
