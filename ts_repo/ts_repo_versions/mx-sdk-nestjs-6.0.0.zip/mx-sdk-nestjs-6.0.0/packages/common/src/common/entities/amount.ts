export class Amount extends String { }
