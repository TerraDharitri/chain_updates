export enum ConfigurationLoaderSchemaType {
  json = 'json',
  yaml = 'yaml',
}
