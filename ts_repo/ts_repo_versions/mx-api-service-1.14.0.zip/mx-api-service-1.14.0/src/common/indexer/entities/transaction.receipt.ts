export interface TransactionReceipt {
  receiptHash: string;
  value: string;
  sender: string;
  data: string;
  txHash: string;
  timestamp: number;
}
