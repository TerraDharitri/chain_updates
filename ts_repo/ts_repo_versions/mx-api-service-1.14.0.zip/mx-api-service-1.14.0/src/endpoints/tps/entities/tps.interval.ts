export enum TpsInterval {
  _10m = '10m',
  _1h = '1h',
  _1d = '1d',
}
