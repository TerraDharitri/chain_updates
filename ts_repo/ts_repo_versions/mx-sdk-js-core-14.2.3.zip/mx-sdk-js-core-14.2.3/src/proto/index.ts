/**
 * @packageDocumentation
 * @module proto
 */

export * from "./serializer";
