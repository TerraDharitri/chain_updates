export type PriceRange = {
  minBid: string;
  maxBid: string;
  paymentToken: string;
  paymentDecimals: number;
};
