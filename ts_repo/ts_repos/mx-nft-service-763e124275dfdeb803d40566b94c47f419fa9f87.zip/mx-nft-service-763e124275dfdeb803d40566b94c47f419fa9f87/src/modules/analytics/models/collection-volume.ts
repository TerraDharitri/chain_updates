export class CollectionVolumeLast24 {
  collection: string;
  volume: string;
  tokens: {
    paymentToken: string;
    sum: string;
  };
}
