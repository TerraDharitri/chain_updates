import { U64Value } from '@multiversx/sdk-core';

export interface TimePeriod {
  start: U64Value;
  end: U64Value;
}
