export interface SmartContractApi {
  address: string;
  deployTxHash: string;
}
