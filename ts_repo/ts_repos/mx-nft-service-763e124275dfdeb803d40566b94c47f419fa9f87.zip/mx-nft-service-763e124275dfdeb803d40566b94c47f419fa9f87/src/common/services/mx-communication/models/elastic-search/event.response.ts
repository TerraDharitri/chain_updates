export interface EventResponse {
  address: string;
  identifier: string;
  topics: string[];
  data: string;
  order: number;
}
