export interface CurrencyData {
  time: string;
  data: string;
}
