export interface OwnerApi {
  address: string;
  balance: string;
}
