import kadenaScanActivity from './providers/kadena';

export { kadenaScanActivity };
