export enum StorageKeys {
  accountsState = 'kadena-accounts-state',
}
export interface IState {
  isApproved: boolean;
}
