import subscanActivity from './providers/subscan';

export { subscanActivity };
