import { NetworkNames } from '@enkryptcom/types';

const NATIVE_TOKEN_ADDRESS = '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee';
const MAX_UNAVAILABLE_NETWORKS = [NetworkNames.Optimism];
export { NATIVE_TOKEN_ADDRESS, MAX_UNAVAILABLE_NETWORKS };
