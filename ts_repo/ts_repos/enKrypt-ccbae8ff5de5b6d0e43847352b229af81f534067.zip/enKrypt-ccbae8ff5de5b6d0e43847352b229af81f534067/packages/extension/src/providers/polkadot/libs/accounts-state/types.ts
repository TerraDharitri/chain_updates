export enum StorageKeys {
  accountsState = 'substrate-accounts-state',
}
export interface IState {
  isApproved: boolean;
}
