import { NetworkNames } from '@enkryptcom/types';

const newNetworks: NetworkNames[] = [NetworkNames.Hemi];
const newSwaps: NetworkNames[] = [];

export { newNetworks, newSwaps };
