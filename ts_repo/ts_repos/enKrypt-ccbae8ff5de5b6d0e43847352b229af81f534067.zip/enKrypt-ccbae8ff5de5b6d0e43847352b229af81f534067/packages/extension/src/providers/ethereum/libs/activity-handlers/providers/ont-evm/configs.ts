import { NetworkNames } from '@enkryptcom/types';

export const NetworkEndpoints = {
  [NetworkNames.OntologyEVM]: 'https://explorer.ont.io/',
};
