import kadena from './kadena';
import kadenaTestnet from './kadena-testnet';

export default {
  kadena,
  kadenaTestnet,
};
