export default {
  kdaAccounts: {
    path: 'kda-accounts',
    component: {},
    name: 'kdaAccounts',
  },
  kdaSignMessage: {
    path: 'kda-sign-message',
    component: {},
    name: 'kdaSignMessage',
  },
};
