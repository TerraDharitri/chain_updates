export enum StorageKeys {
  accountsState = 'evm-accounts-state',
}
export interface IState {
  approvedAccounts: string[];
}
