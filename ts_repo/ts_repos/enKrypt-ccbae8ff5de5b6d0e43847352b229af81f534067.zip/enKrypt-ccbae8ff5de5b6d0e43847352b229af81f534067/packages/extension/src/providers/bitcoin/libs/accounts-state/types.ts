export enum StorageKeys {
  accountsState = 'bitcoin-accounts-state',
}
export interface IState {
  approvedAccounts: string[];
}
