export default {
  btcSign: {
    path: 'btc-sign',
    name: 'btcSign',
    component: {},
  },
  btcSendTransaction: {
    path: 'btc-send-transaction',
    name: 'btcSendTransaction',
    component: {},
  },
  btcConnectDApp: {
    path: 'btc-connect-dapp',
    name: 'btcConnectDApp',
    component: {},
  },
  btcHWVerify: {
    path: 'btc-hw-verify',
    name: 'btcHWVerify',
    component: {},
  },
};
