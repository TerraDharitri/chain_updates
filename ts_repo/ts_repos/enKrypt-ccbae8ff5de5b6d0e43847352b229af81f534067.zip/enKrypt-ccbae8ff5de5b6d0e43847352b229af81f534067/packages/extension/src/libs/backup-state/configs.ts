const BACKUP_URL = 'https://backupstore.enkrypt.com/';
const HEADERS = {
  Accept: 'application/json',
  'Content-Type': 'application/json',
};
export { BACKUP_URL, HEADERS };
