export enum StorageKeys {
  providerInfo = 'provider-info',
}
export interface IState {
  selectedNetwork?: string;
  selectedSubNetworkId?: string;
  selectedAddress?: string;
}
