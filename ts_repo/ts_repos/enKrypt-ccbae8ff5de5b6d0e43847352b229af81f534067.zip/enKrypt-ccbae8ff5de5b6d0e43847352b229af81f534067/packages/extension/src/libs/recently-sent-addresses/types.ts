export type IState = {
  addresses: string[]
}
