export enum StorageKeys {
  menuState = 'menu-state-info',
}

export interface IState {
  isExpanded: boolean;
}
