export const EXTENSION_NAMESPACE =
  'dfc62431af1c3c1258035e5ab4058b6440e507238cf0fe429ea39827a7ee43fc'; //keccak256("enkrypt")
