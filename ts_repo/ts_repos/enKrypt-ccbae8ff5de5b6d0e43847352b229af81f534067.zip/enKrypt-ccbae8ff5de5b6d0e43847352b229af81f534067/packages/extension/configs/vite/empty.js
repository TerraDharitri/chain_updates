const readFileSync = () => {};
const writeFileSync = () => {};

export { readFileSync, writeFileSync };
