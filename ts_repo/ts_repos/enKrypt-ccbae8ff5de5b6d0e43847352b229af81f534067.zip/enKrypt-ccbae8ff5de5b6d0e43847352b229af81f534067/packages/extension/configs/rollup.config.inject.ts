import Base from './rollup.config.base'
export default Object.assign({ input: ['src/scripts/inject.ts'] }, Base)
