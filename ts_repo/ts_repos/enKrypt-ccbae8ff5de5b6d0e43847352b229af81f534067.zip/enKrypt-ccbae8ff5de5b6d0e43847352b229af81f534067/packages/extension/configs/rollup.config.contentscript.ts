import Base from './rollup.config.base'
export default Object.assign({ input: ['src/scripts/contentscript.ts'] }, Base)
