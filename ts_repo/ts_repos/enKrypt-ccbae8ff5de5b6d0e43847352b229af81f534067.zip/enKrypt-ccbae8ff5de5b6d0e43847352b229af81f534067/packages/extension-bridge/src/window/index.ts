export {
  allowWindowMessaging,
  setNamespace,
  getCurrentContext,
} from "./internal";

export { sendMessage, onMessage } from "./apis";
