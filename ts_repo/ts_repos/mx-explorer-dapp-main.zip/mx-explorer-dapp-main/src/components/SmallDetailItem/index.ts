export * from './SmallDetailItem';
