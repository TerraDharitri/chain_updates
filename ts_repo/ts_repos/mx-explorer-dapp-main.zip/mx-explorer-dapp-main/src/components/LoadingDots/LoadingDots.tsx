export const LoadingDots = () => <div className='loading-dots'></div>;
