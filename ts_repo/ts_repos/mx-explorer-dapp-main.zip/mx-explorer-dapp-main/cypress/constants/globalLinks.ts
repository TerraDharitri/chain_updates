export const TESTNET_API = 'https://testnet-api.multiversx.com/';
export const DEVNET_API = 'https://devnet-api.multiversx.com/';
export const DEVNET_TOOLS_API = 'https://devnet-tools.multiversx.com/';
