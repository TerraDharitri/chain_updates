#!/bin/bash

cp ./src/icons/duotone/fontawesomeFree.ts ./src/icons/duotone/index.ts
cp ./src/icons/light/fontawesomeFree.ts ./src/icons/light/index.ts
cp ./src/icons/regular/fontawesomeFree.ts ./src/icons/regular/index.ts
cp ./src/icons/solid/fontawesomeFree.ts ./src/icons/solid/index.ts

echo 'Using Fontawesome Free Icons'
