import { Component } from '@angular/core';

@Component({
  selector: 'app-unlock-page',
  standalone: true,
  imports: [],
  templateUrl: './unlock-page.component.html',
  styleUrls: ['./unlock-page.component.css'],
})
export class UnlockPageComponent {}
