export interface WithClassnameType {
  className?: string;
} 