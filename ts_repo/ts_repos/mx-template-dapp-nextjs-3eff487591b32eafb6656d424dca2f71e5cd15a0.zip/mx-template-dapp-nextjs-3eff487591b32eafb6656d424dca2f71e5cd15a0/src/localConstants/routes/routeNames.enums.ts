export enum RouteNamesEnum {
  home = '/',
  dashboard = '/dashboard',
  disclaimer = '/disclaimer'
}
