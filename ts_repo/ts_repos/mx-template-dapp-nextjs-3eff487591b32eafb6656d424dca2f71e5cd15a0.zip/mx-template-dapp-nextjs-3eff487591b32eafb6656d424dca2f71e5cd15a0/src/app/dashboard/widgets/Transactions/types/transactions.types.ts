export type TransactionsPropsType = {
  receiver?: string;
};
