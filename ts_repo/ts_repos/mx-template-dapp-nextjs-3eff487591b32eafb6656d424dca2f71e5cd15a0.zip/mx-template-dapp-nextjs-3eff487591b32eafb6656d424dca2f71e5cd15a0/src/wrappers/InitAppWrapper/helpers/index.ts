export * from './initAppSingleton';
