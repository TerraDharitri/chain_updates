export const isWindowAvailable = () => {
  return typeof window !== 'undefined';
};
