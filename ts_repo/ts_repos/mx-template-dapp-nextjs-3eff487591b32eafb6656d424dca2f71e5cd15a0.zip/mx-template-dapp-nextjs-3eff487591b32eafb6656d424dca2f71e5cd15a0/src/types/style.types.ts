export type WithClassnameType = {
  className?: string;
  'data-testid'?: string;
};
