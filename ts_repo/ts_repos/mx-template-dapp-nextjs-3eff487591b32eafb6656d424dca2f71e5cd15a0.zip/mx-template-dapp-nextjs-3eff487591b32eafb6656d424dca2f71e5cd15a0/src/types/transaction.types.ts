export type TransactionProps = {
  address: string;
  nonce: number;
  chainID: string;
};
