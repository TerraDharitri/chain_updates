export enum CypressEnums {
  transactionBtn = 'transactionBtn'
}
