export type ProfileType = {
  address: string;
  username: string;
  balance: string;
  nonce: number;
  shard: number;
};
