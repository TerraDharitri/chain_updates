export const DEVNET_API = 'https://devnet-api.multiversx.com';
