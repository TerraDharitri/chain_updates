export * from './globalData';
