export const userData = {
  passsword: 'Develop13#',
  adress: 'erd1z9ewlfndgp6dwu8s6cprl2e0xw70fyeazsmwa28xpwaga75qfquqmzjm29'
};
