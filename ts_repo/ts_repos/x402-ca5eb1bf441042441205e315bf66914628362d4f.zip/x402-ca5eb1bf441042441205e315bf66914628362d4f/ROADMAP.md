# Roadmap

This file contains desired large features the x402 team would like to see developed. We will as we have bandwidth prioritize items listed under `Open for contribution`, but we would love community involvement and help to add these features

## CDP Lead

- [ ] [`In Progress`] Mainnet Base

## Open for contribution

- [ ] `exact` scheme support on SVM
- [ ] `upto` scheme EVM & SVM
- [ ] easier semantics for arbitrary tokens using permit as an alt method to `transferWithAuthorization` (likely via `permit` and an up to scheme)
