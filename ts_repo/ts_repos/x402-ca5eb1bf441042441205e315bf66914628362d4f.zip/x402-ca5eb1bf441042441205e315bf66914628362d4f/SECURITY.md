# Security Policy

The Coinbase team takes security seriously. Please do not file a public ticket discussing a potential vulnerability.

Please report your findings through our [HackerOne][1] program.

[1]: https://hackerone.com/coinbase
