export type Resource = `${string}://${string}`;
