export enum ThemesEnum {
  light = 'mvx:light-theme',
  dark = 'mvx:dark-theme'
}
