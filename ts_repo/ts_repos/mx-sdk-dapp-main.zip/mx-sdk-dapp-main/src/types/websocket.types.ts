export type BatchTransactionsWSResponseType = {
  batchId: string;
  txHashes: string[];
};
