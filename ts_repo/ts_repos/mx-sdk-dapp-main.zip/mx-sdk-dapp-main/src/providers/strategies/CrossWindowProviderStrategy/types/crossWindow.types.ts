export interface CrossWindowConfig {
  /**
   * default: `false`
   */
  isBrowserWithPopupConfirmation?: boolean;
}
