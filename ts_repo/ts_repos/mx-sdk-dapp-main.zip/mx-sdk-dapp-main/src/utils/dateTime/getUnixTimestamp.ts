export const getUnixTimestamp = () => {
  return Date.now() / 1000;
};
