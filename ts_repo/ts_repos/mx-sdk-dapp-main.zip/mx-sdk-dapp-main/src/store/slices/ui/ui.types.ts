export interface UiSliceType {
  isSidePanelOpen: boolean;
}
