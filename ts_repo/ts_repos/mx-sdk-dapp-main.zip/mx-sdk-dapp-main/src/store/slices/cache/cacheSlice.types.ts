export type CacheSliceType = {
  [key: string]: unknown;
};
