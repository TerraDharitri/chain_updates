import { StoreType } from 'store/store.types';

export const stateSelector = (state: StoreType) => state;
