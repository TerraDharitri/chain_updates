export enum UITagsEnum {
  LEDGER_CONNECT = 'mvx-ledger-connect',
  NOTIFICATIONS_FEED = 'mvx-notifications-feed',
  PENDING_TRANSACTIONS_PANEL = 'mvx-pending-transactions-panel',
  SIGN_TRANSACTIONS_PANEL = 'mvx-sign-transactions-panel',
  TOAST_LIST = 'mvx-toast-list',
  WALLET_CONNECT = 'mvx-wallet-connect',
  UNLOCK_PANEL = 'mvx-unlock-panel'
}
