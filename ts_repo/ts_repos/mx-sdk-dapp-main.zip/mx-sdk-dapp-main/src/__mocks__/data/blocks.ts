export const blocks = [
  {
    hash: 'fff67d31476ad920d53093a3a4c2178e198179b35656eeefa419107fa718b780',
    timestamp: 1671204768
  }
];
