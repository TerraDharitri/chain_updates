export const account = {
  address: 'erd1spyavw0956vq68xj8y4tenjpq2wd5a9p2c6j8gsz7ztyrnpxrruqzu66jx',
  balance: '116893786890813785912',
  nonce: 12320,
  shard: 0,
  rootHash: 'wICKVeNpCg/TsBRyRyZMMMhcW1KENpAbopfinRVyENQ=',
  txCount: 12655,
  scrCount: 14084,
  developerReward: '0'
};
