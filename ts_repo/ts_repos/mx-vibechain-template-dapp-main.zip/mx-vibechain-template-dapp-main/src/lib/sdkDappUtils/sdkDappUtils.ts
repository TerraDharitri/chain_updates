export { DECIMALS, DIGITS } from "@multiversx/sdk-dapp-utils/out/constants";
export { formatAmount } from "@multiversx/sdk-dapp-utils";
