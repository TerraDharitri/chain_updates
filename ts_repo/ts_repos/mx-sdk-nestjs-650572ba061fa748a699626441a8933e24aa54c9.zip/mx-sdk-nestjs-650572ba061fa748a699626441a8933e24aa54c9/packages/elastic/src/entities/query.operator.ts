export enum QueryOperator {
  AND = 'AND',
  OR = 'OR'
}
