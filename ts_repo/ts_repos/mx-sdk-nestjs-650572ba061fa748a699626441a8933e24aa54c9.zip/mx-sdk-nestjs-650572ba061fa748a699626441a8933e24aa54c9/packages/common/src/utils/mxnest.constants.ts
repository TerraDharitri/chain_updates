export const MXNEST_CONFIG_SERVICE = 'MxnestConfigService';
