export interface InMemoryCacheOptions {
  maxItems?: number;
  skipItemsSerialization?: boolean;
}
