export class LocalCacheValue {
  value: any;

  expires: number = 0;
}
