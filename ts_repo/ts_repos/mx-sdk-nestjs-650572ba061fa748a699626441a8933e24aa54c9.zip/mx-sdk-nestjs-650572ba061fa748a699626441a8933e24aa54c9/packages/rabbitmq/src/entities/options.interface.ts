export interface OptionsInterface {
  logsVerbose?: boolean;
  checkForDuplicates?: boolean;
  duplicatesCheckTtl?: number;
}
